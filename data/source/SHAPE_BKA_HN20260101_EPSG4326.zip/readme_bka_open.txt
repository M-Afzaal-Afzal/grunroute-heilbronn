Hinweise zum Baumkataster der Stadt Heilbronn:
Stand: 01.01.2026

Koordinatensystem: UTM32N (EPSG Code 25832) bzw.
		   WGS84 (EPSG Code 4326)
Codepage der dbf-Datei: utf-8

Tabellenaufbau der Fachdaten:
BAUM_NR    interne Baumnummer im Baumkataster
ORT        Stadt
STADTTEIL  Stadtteil
STRASSE    Stra�e
TYP        Baumtyp (Laubbaum, Nadelbaum, Obstbaum, Baumgruppe)
DEU_TEXT   Deutscher Name
WIS_TEXT   Wissenschaftlicher Name
ST_UMFANG  Stammumfang in m
KRONE_DM   Kronendurchmesser in m

Neben den Baumtypen (TYP) Laubbaum, Nadelbaum und Obstbaum gibt es auch 
noch Baumgruppen. Hier sind mehrere gleichartige B�ume zusammengefasst. 
Der gespeicherte Stammumfang entspricht hier dann der Summe der Einzel-
st�mme.

Im Baumkataster sind neben st�dtischen B�umen z.T. auch B�ume z.B. anderer 
Stellen (Stadtwerke, Wasser- und Schifffahrtsdirektion...) gespeichert,
die aber nicht der Baumkontrolle der Stadt Heilbronn unterliegen.
Solche B�ume haben dann oftmals nur einen Standardkronendurchmesser von 2m, 
auch wenn die B�ume in Natura wesentlich gr��er sind.
